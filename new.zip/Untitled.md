

```python
%matplotlib inline
```


```python
import numpy as np
```


```python
from sklearn.cluster import KMeans
```


```python
import pandas as pd
```


```python
df = pd.read_csv('data_1024.csv',sep='\t')
df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Driver_ID</th>
      <th>Distance_Feature</th>
      <th>Speeding_Feature</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3423311935</td>
      <td>71.24</td>
      <td>28.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3423313212</td>
      <td>52.53</td>
      <td>25.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3423313724</td>
      <td>64.54</td>
      <td>27.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3423311373</td>
      <td>55.69</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3423310999</td>
      <td>54.58</td>
      <td>25.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt
```


```python
plt.plot(df['Distance_Feature'], df['Speeding_Feature'],'ro')
plt.xlabel('Distance_Feature')
plt.ylabel('Speeding_Feature')
plt.show()
```


![png](output_6_0.png)



```python
f1 = df['Distance_Feature'].values
f2 = df['Speeding_Feature'].values
X = np.matrix(list(zip(f1,f2)))
kmeans = KMeans(n_clusters = 2).fit(X)
kmeans.labels_

```




    array([0, 0, 0, ..., 1, 1, 1], dtype=int32)




```python
centroids = kmeans.cluster_centers_
centroids
```




    array([[  50.04763437,    8.82875   ],
           [ 180.017075  ,   18.29      ]])




```python
plt.plot(df['Distance_Feature'], df['Speeding_Feature'],'ro')
plt.xlabel('Distance_Feature')
plt.ylabel('Speeding_Feature')
plt.scatter(centroids[:, 0], centroids[:, 1],
            marker='x', s=169, linewidths=3,
            color='b', zorder=10)
```




    <matplotlib.collections.PathCollection at 0x10d789908>




![png](output_9_1.png)



```python
kmeans4 = KMeans(n_clusters = 4).fit(X)
centroids4 = kmeans4.cluster_centers_
centroids4


```




    array([[  49.99263253,    5.20447169],
           [ 180.34311782,   10.52011494],
           [  50.40482436,   32.36533958],
           [ 177.83509615,   70.28846154]])




```python
plt.plot(df['Distance_Feature'], df['Speeding_Feature'],'ro')
plt.xlabel('Distance_Feature')
plt.ylabel('Speeding_Feature')
plt.xlim(0, 300)
plt.ylim(0,100)
plt.scatter(centroids4[:, 0],centroids4[:,1], 
            marker='x', s=169, linewidths=3,
            color='b', zorder=10)
```




    <matplotlib.collections.PathCollection at 0x10d85df60>




![png](output_11_1.png)



```python
from scipy.spatial.distance import cdist
distortions = []
K = range(1,15)
for k in K:
    Kmeans_new = KMeans(n_clusters = k).fit(X)
    Kmeans_new.fit(X)
    distortions.append((np.min(cdist(X, Kmeans_new.cluster_centers_))).sum())

#plot elbow
plt.plot(K, distortions, 'bx-')
plt.xlabel('k')
plt.ylabel('distortions')
plt.show()
```


![png](output_12_0.png)

